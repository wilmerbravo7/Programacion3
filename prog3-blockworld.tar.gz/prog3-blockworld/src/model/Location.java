package model;
//Tener en cuenta la documentacion de la practica mirarlo bien
//package Location;
import java.util.*;
import java.lang.Math;


public class Location{
  //Parte privada del programa.
  //Para cada atributo tenemos que comentar su finalidad
      private double x;
      private double y;
      private double z;
      private World world;
//Parte publica del programa.
    public static final double UPPER_Y_VALUE = 255.0;
    public  static final double SEA_LEVEL = 63.0;
    //Constructor por parametros
    //Comentar que es lo que hace cada metodo
    public Location(World w, double x, double y, double z){
      world = w;
      setX(x);
      setY(y);
      setZ(z);
    }
    //Constructor de copia
    public Location(Location l){
      //No se si es con punto o con ->
      world = l.world;
      x = l.x;
      y = l.y;
      z = l.z;
    }
    //Añadir una localizacion. Equivalente en con el operador += en c++
    public Location add(Location l){
      if(l.world != world){
        System.out.println("Cannot add Locations of differing worlds");
      } else {
        x += l.x;
        setY(y + l.y);
        z += l.z;
      }
      return this;
    }
    //Calcular distancia
    public double distance(Location l){
    	/*
      if(l.getWorld() == NULL || getWorld() == NULL){//Aquir podemos utilizar otra cosa
        System.out.println("Cannot measure distance to a null world");
        return -1.0;
       } else if (l.getWorld() != getWorld()){
            System.out.print("Cannot measure distance between"+ world.getName() + "and" + l.world.getName());
            //Queda por implementar la clase world.
            return -1.0;
          }
          */
          double dx = x - l.x;
          double dy = y - l.y;
          double dz = z - l.z;
          return Math.sqrt(dx*dx + dy*dy +dz*dz);
        }
    //Get de cada uno de los atributos privados
    public World getWorld(){
      return world;
    }
    public double getX(){
      return x;
    }
    public double getY(){
      return y;
    }
    public double getZ(){
      return z;
    }
    //Set de cada uno de los atributos privados
    public void setWorld(World w){
      world = w;
    }
    public void setX(double x){
      this.x = x;
    }
    public void setY(double y){
      this.y = y;
    }
    public void setZ(double z){
      this.z = z;
    }
    //Calcular longitud
    public final double length(){
      return Math.sqrt(x*x + y*y +z*z);
    }
    //Multiplicar por un numero la localizacion
    public Location multiply(double factor){
      x *= factor;
      setY(y * factor);
      z *= factor;
      return this;
    }
    //Obtenemos un localizacion
    public Location substract(Location l){
      if(l.world != world){
        System.out.println("Cannot substract Locations of differing worlds.");
      } else {
        x -= l.x;
        setY(y - l.y);
        z -= l.z;
      }
      return this;
    }

    //Poner la localizacion a cero
    public Location zero(){
      x = y = z = 0.0;
      return this;
    }
    //Metodo equals
}
