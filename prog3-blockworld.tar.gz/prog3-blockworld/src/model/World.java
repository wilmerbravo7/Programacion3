package model;
public class World {
  //Parte privada de la clase
  private String name;
  //Parte publica de la clase World
  public World(String name){
    this.name = name;
  }
  public String getName(){
    return name;
  }

}
